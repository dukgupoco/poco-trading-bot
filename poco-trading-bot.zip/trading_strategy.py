import pandas as pd
import numpy as np

class TradingStrategy:
    def __init__(self, api):
        self.api = api

    def get_market_data(self, symbol, timeframe="1h"):
        return self.api.fetch_ohlcv(symbol, timeframe)

    def apply_strategy(self, market_data):
        df = pd.DataFrame(market_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        df['sma_20'] = df['close'].rolling(window=20).mean()
        df['sma_50'] = df['close'].rolling(window=50).mean()
        
        df['signal'] = np.where(df['sma_20'] > df['sma_50'], 1, -1)
        return df

    def run(self):
        market_data = self.get_market_data("BTC/USDT")
        df = self.apply_strategy(market_data)

        if df['signal'].iloc[-1] == 1:
            self.api.place_order("BTC/USDT", "buy", 0.01)
        elif df['signal'].iloc[-1] == -1:
            self.api.place_order("BTC/USDT", "sell", 0.01)
