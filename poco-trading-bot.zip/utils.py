import logging
from datetime import datetime

# 로그 설정
logging.basicConfig(filename='poco.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def log_message(message):
    """로그를 기록하는 함수"""
    logging.info(message)

def timestamp_to_date(timestamp):
    """타임스탬프를 읽기 쉬운 날짜 형식으로 변환"""
    return datetime.utcfromtimestamp(timestamp / 1000).strftime('%Y-%m-%d %H:%M:%S')
