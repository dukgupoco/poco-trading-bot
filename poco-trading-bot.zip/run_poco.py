import json
import time
from trading_strategy import TradingStrategy
from exchange_api import ExchangeAPI

# 설정 파일 로드
with open("config.json", "r") as config_file:
    config = json.load(config_file)

# 거래소 API 연결
api = ExchangeAPI(api_key=config["api_key"], secret=config["api_secret"])

# 트레이딩 전략 인스턴스 생성
strategy = TradingStrategy(api)

def main():
    while True:
        strategy.run()
        time.sleep(config["trade_interval"])

if __name__ == "__main__":
    main()