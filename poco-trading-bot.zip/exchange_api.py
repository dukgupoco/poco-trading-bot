import ccxt

class ExchangeAPI:
    def __init__(self, api_key, secret):
        self.exchange = ccxt.binance({
            'apiKey': api_key,
            'secret': secret
        })

    def fetch_ohlcv(self, symbol, timeframe="1h"):
        return self.exchange.fetch_ohlcv(symbol, timeframe)

    def place_order(self, symbol, side, amount):
        order = self.exchange.create_market_order(symbol, side, amount)
        return order

    def get_balance(self):
        return self.exchange.fetch_balance()
